declare module '*.png' {
  let _: string;
  export = _;
}

declare module '*.json' {
  let _: object;
  export = _;
}

declare module '*.svg' {
  let _: string;
  export = _;
}
