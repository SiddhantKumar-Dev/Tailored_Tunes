export * from './util/component';
export as namespace ExtensionCoordinator;
