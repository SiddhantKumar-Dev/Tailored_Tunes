interface Window {
  'extension-coordinator': typeof ExtensionCoordinator;

  rig: GlobalExtensionRig;
  location: Location;
}
