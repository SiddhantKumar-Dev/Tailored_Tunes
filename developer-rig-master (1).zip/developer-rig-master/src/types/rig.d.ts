interface GlobalExtensionRig {
  history: {
    frame: string;
    log: string;
  }[]
  update: () => void;
}
