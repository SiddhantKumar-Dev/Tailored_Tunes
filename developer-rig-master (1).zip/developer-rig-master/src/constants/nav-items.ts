export const ExtensionViews = 'Extension Views';
export const BroadcasterConfig = 'Broadcaster Config';
export const LiveConfig  = 'Live Config';
export const Configurations  = 'Configurations';
export const ProductManagement = 'Product Management';
