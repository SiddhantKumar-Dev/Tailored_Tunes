export const RigRole = 'rig';
