export const IdentityOptions = {
  Linked: "Linked",
  Unlinked: "Unlinked"
};
export const DefaultIdentityOption = IdentityOptions.Unlinked;
