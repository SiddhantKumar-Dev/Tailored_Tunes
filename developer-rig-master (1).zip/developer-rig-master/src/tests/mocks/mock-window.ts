export interface Window {
  rig: {
    [key: string]: { },
  };
  [key: string]: { };
}
