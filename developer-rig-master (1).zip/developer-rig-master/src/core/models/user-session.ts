export interface UserSession {
  login?: string;
  authToken?: string;
  profileImageUrl?: string;
}
