import { RigStore } from "./rig-store";

export const store = new RigStore();
