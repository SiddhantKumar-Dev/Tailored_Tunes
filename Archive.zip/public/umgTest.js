
import oauthSignature from 'oath-signature'

var httpMethod = 'GET',
   url = 'https://stream.svc.7digital.net/stream/catalogue',
    parameters = {
        oauth_consumer_key : '7d4vr6cgb392',
        oauth_token : 'nnch734d00sl2jdk',
        oauth_nonce : 'kllo9940pd9333jh',
        oauth_timestamp : '1191242096',
        oauth_signature_method : 'HMAC-SHA1',
        oauth_version : '1.0',
        trackId : process.argv[2],
        shopId : 2020,
        file : 'catalogue.mp3',
        size : 'original'
    }
    consumerSecret = 'm4ntskavq56rddsa',
    tokenSecret = '',
    encodedSignature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret, tokenSecret),
    signature = oauthSignature.generate(httpMethod, url, parameters, consumerSecret, tokenSecret,
        { encodeSignature: false});
