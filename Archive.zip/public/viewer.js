var token = "";
var tuid = "";
var ebs = "";

// because who wants to type this every time?
var twitch = window.Twitch.ext;
var linkPt1 = 'https://stream.svc.7digital.net/stream/catalogue?oauth_consumer_key=7d4vr6cgb392&oauth_nonce=961045184&oauth_signature_method=HMAC-SHA1&oauth_timestamp=1533463854&oauth_version=1.0&shopId=2020&trackId='
var linkPt2 = '&oauth_signature=EzuuGV9Np9RIzZs7BFCgQQ%2BJIGo%3D'
twitch.rig.log(linkPt1+linkPt2);

var level1 = [23048835, 864400];
var level2 = [2853905, 18833190];
var level3 = [23048828];
var level4 = [49068930];
var level5 = [23048816];

//make a variable with some search queries and put it in an array. (you can create more search queries.
// $getRandomSongsArray = array('%25a%25', 'a%25', '%25e%25', 'e%25', '%25i%25', 'i%25', '%25o%25', 'o%25');
// $getRandomSongs = $getRandomSongsArray[array_rand($getRandomSongsArray)];
// $getRandomOffset = rand(1, 1000);
// $url = "https://api.spotify.com/v1/search?query=$getRandomSongs&offset=$getRandomOffset&limit=1&type=track&market=NL";
// twitch.rig.log($url);


var audio1 = new Audio();
var audio2 = new Audio();
var audio3 = new Audio();
var audio4 = new Audio();
var audio5 = new Audio();




var mood = 0;

// create the request options for our Twitch API calls
var requests = {
    set: createRequest('POST', 'cycle'),
    get: createRequest('GET', 'query')
};

function createRequest(type, method) {
    return {
        type: type,
        url: 'https://localhost:8081/color/' + method,
        success: updateBlock,
        error: logError
    }
}

function setAuth(token) {
    Object.keys(requests).forEach((req) => {
        twitch.rig.log('Setting auth headers');
        requests[req].headers = { 'Authorization': 'Bearer ' + token }
    });
}

twitch.onContext(function(context) {
    twitch.rig.log(context);
});

twitch.onAuthorized(function(auth) {
    // save our credentials
    token = auth.token;
    tuid = auth.userId;

    // enable the button
    $('#cycle1').removeAttr('disabled');
    $('#cycle2').removeAttr('disabled');
    $('#cycle3').removeAttr('disabled');
    $('#cycle4').removeAttr('disabled');
    $('#cycle5').removeAttr('disabled');


    setAuth(token);
    $.ajax(requests.get);
});

function updateBlock(hex) {

}

function logError(_, error, status) {
  twitch.rig.log('EBS request returned '+status+' ('+error+')');
}

function logSuccess(hex, status) {
  // we could also use the output to update the block synchronously here,
  // but we want all views to get the same broadcast response at the same time.
  twitch.rig.log('EBS request returned '+hex+' ('+status+')');
}

function hello(buttonNumber){
    var number = 11;
    var songId = 000000;
    switch (buttonNumber){
        case 1:
            number = Math.floor(Math.random()*level1.length);
            songId = level1[number];
            break;
        case 2:
            number = Math.floor(Math.random()*level2.length);
            songId = level2[number];
            break;
        case 3:
            number = Math.floor(Math.random()*level3.length);
            songId = level3[number];
            break;
        case 4:
            number = Math.floor(Math.random()*level4.length);
            songId = level4[number];
            break;
        case 5:
            number = Math.floor(Math.random()*level5.length);
            songId = level5[number];
            break;
        default:
            number = 1;

    }

    var link = linkPt1+songId+linkPt2;
    twitch.rig.log(link);
    audio1.src = link;
    audio2.src = link;
    audio3.src = link;
    audio4.src = link;
    audio5.src = link;
    if(buttonNumber == 1){
        twitch.rig.log("Going to play the first song");
        audio2.pause();
        audio3.pause();
        audio4.pause();
        audio5.pause();
        audio1.play();
    }
    else if(buttonNumber == 2){
        twitch.rig.log("Going to play the second song");
        audio1.pause();
        audio3.pause();
        audio4.pause();
        audio5.pause();
        audio2.play();
    }
    else if(buttonNumber == 3){
        twitch.rig.log("Going to play the third song");
        audio2.pause();
        audio1.pause();
        audio4.pause();
        audio5.pause();
        audio3.play();
    }
    else if(buttonNumber == 4){
        twitch.rig.log("Going to play the fourth song");
        audio2.pause();
        audio3.pause();
        audio1.pause();
        audio5.pause();
        audio4.play();
    }
    else{
        twitch.rig.log("Going to play the fifth song");
        audio2.pause();
        audio3.pause();
        audio4.pause();
        audio1.pause();
        audio5.play();
    }
}

$(function() {

    // when we click the cycle button
    $('#cycle1').click(function() {
        if(!token) { return twitch.rig.log('Not authorized'); }
        twitch.rig.log('Currently the level is very low');
        mood = 1;
        twitch.rig.log(mood);
        hello(1);
        $.ajax(requests.set);
    });

    $('#cycle2').click(function() {
        if(!token) { return twitch.rig.log('Not authorized'); }
        twitch.rig.log('Currently the level is low');
        mood = 2;
        twitch.rig.log(mood);
        hello(2);
        $.ajax(requests.set);
    });

    $('#cycle3').click(function() {
        if(!token) { return twitch.rig.log('Not authorized'); }
        twitch.rig.log('Currently the level is medium');
        mood = 3;
        twitch.rig.log(mood);
        hello(3);
        $.ajax(requests.set);
    });

    $('#cycle4').click(function() {
        if(!token) { return twitch.rig.log('Not authorized'); }
        twitch.rig.log('Currently the level is high');
        mood = 4;
        twitch.rig.log(mood);
        hello(4);
        $.ajax(requests.set);
    });

    $('#cycle5').click(function() {
        if(!token) { return twitch.rig.log('Not authorized'); }
        twitch.rig.log('Currently the level is very high');
         mood = 5;
         twitch.rig.log(mood);
         hello(5);
        $.ajax(requests.set);
    });

    // listen for incoming broadcast message from our EBS
    // twitch.listen('broadcast', function (target, contentType, color) {
    //     twitch.rig.log('Received broadcast color');
    //     updateBlock(color);
    // });
});
